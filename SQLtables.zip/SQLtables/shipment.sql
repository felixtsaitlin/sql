drop table `shipments`;

CREATE TABLE `shipments` (
	`shipment_id` int NOT NULL AUTO_INCREMENT,
	`shipment_cost` int unsigned not null,	
    `shipment_by` int unsigned not null, 
    `tran_id` int unsigned not null,
    `shipment_status` int unsigned not null,
    `shipment_date` date,
    
  PRIMARY KEY (`shipment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

insert 
into shipments (shipment_id,shipment_cost,shipment_by,tran_id,shipment_status,shipment_date) 
values (1,100,1,1,4,'2020-01-01');

insert 
into shipments (shipment_id,shipment_cost,shipment_by,tran_id,shipment_status,shipment_date) 
values (2,57,2,1,4,'2020-01-03');

insert 
into shipments (shipment_id,shipment_cost,shipment_by,tran_id,shipment_status,shipment_date) 
values (3,67,1,1,4,'2020-01-07');


insert 
into shipments (shipment_id,shipment_cost,shipment_by,tran_id,shipment_status,shipment_date) 
values (4,0,6,2,4,'2019-07-04');

insert 
into shipments (shipment_id,shipment_cost,shipment_by,tran_id,shipment_status,shipment_date) 
values (5,0,6,3,4,'2020-07-30');

insert 
into shipments (shipment_id,shipment_cost,shipment_by,tran_id,shipment_status,shipment_date) 
values (6,0,6,4,4,'2020-07-27');

insert 
into shipments (shipment_id,shipment_cost,shipment_by,tran_id,shipment_status,shipment_date) 
values (7,0,6,5,4,'2020-07-29');

insert 
into shipments (shipment_id,shipment_cost,shipment_by,tran_id,shipment_status,shipment_date) 
values (8,121,2,5,2,'2020-08-01');

insert 
into shipments (shipment_id,shipment_cost,shipment_by,tran_id,shipment_status,shipment_date) 
values (9,33,4,6,4,'2020-02-26');

insert 
into shipments (shipment_id,shipment_cost,shipment_by,tran_id,shipment_status,shipment_date) 
values (10,29,3,6,4,'2020-02-27');

insert 
into shipments (shipment_id,shipment_cost,shipment_by,tran_id,shipment_status,shipment_date) 
values (11,0,5,7,4,'2017-01-01');

insert 
into shipments (shipment_id,shipment_cost,shipment_by,tran_id,shipment_status,shipment_date) 
values (12,0,6,8,4,'2016-01-01');

insert 
into shipments (shipment_id,shipment_cost,shipment_by,tran_id,shipment_status,shipment_date) 
values (13,33,2,9,4,'2017-01-07');

insert 
into shipments (shipment_id,shipment_cost,shipment_by,tran_id,shipment_status,shipment_date) 
values (14,66,4,9,4,'2017-01-25');

insert 
into shipments (shipment_id,shipment_cost,shipment_by,tran_id,shipment_status,shipment_date) 
values (15,15,1,10,4,'2018-06-03');




select * from shipments;

select 	count(*)
from 	shipments 
where 	shipment_date >= '2017-01-01' and 
		shipment_date < '2017-02-01' and
        shipment_by in (select shipment_by_id from shipment_by where shipper = 'X-press') ;

select 	sum(tran_val)
from 	transactions
where 	tran_date >= '2017-01-01' and 
		tran_date < '2017-02-01' and
        pay_method_id = 2;
