drop table `translations`;

