drop table `orders`;

CREATE TABLE `orders` (
	`order_id` int NOT NULL AUTO_INCREMENT,
	`customer_id` int unsigned,
	`book_id` int unsigned,
    `order_date` date,
    `book_exists` bool,
    `purchased` bool, 

  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


insert 
into orders (order_id, customer_id,book_id,order_date,book_exists,purchased) 
values (1,2,2,'2014-04-04',true,true);

insert 
into orders (order_id, customer_id,book_id,order_date,book_exists,purchased) 
values (2,2,3,'2015-05-05',true,true);

insert 
into orders (order_id, customer_id,book_id,order_date,book_exists,purchased) 
values (3,1,7,'2015-12-03',true,false);

insert 
into orders (order_id, customer_id,book_id,order_date,book_exists,purchased) 
values (4,1,6,'2018-11-11',true,true);

insert 
into orders (order_id, customer_id,book_id,order_date,book_exists,purchased) 
values (5,7,1,'2020-01-03',true,false);

insert 
into orders (order_id, customer_id,book_id,order_date,book_exists,purchased) 
values (6,8,3,'2019-12-17',false,false);

insert 
into orders (order_id, customer_id,book_id,order_date,book_exists,purchased) 
values (7,1,10,'2020-02-02',true,true);

insert 
into orders (order_id, customer_id,book_id,order_date,book_exists,purchased) 
values (8,6,8,'2018-06-07',false,false);

insert 
into orders (order_id, customer_id,book_id,order_date,book_exists,purchased) 
values (9,8,8,'2020-06-18',true,true);

insert 
into orders (order_id, customer_id,book_id,order_date,book_exists,purchased) 
values (10,4,5,'2017-07-03',true,false);


select * from orders;

select orders.book_id,order_date,book_exists,purchased,title
                           from orders,books
                           where customer_id=1 and books.book_id=orders.book_id
                           order by order_date ;
                           
