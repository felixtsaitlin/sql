drop table `authors`;


CREATE TABLE `authors` (
	`author_id` int NOT NULL AUTO_INCREMENT,
	`author_name` varchar(45) NOT NULL,
	
  PRIMARY KEY (`author_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


insert 
into authors (author_id, author_name) 
values (1,'dani dani');

insert 
into authors (author_id, author_name) 
values (2,'moshe moshe');

insert 
into authors (author_id, author_name) 
values (3,'gabi gabi');

insert 
into authors (author_id, author_name) 
values (4,'bibi bibi');

insert 
into authors (author_id, author_name) 
values (5, 'ganz ganz');

insert 
into authors (author_id, author_name) 
values (6,'yair lapid' );

insert 
into authors (author_id, author_name) 
values (7,'naftali benet');

insert 
into authors (author_id, author_name) 
values (8, 'zipi livni');

insert 
into authors (author_id, author_name) 
values (9, 'shasha biton');

insert 
into authors (author_id, author_name) 
values (10, 'pikachu ash');



/*task 6*/


select 	author_name,count(*) num
from   	books b,author_for_book afb,authors a,books_for_shipment bfs
where  	b.book_id = afb.book_id and 
		afb.author_id = a.author_id and
        b.book_id = bfs.book_id and
	b.book_id in
    (
select 	book_id
from	books b
where 	book_id	in 
		(select 	book_id 
		 from 	books_for_shipment 
		 where 	ship_id in 
				 (select	shipment_id 
				  from 	    shipments s 
				  where 	tran_id in 
							(select  t.tran_id
							from    transactions t
							where 	 t.tran_date between '2019-01-01' and '2020-07-28'
                            )	
				 )
        )
        
	)
group by afb.author_id
order by num desc;