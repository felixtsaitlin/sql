drop table `customer_purchases`;
