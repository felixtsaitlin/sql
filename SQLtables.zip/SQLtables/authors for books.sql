drop table author_for_book;

CREATE TABLE `author_for_book` (
	`author_id` int unsigned,
	`book_id` int unsigned,
	
  PRIMARY KEY (`author_id`,`book_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

insert 
into author_for_book (author_id, book_id) 
values (1,1);

insert 
into author_for_book (author_id, book_id) 
values (2,2);

insert 
into author_for_book (author_id, book_id) 
values (2,3);

insert 
into author_for_book (author_id, book_id) 
values (2,4);

insert 
into author_for_book (author_id, book_id) 
values (5, 3);

insert 
into author_for_book (author_id, book_id) 
values (6,3);

insert 
into author_for_book (author_id, book_id) 
values (7,3);

insert 
into author_for_book (author_id, book_id) 
values (8, 6);

insert 
into author_for_book (author_id, book_id) 
values (9, 7);

insert 
into author_for_book (author_id, book_id) 
values (10,1);

select * from author_for_book