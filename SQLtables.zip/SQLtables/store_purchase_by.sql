drop table store_purchase_types;

CREATE TABLE `store_purchase_types` (
`store_pur_type_id` int NOT NULL AUTO_INCREMENT,
`store_pur_type_name` varchar(45),

PRIMARY KEY (`store_pur_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

insert into store_purchase_types (store_pur_type_id, store_pur_type_name )
values(1,'supplier');

insert into store_purchase_types (store_pur_type_id, store_pur_type_name )
values(2,'library');

insert into store_purchase_types (store_pur_type_id, store_pur_type_name )
values(3,'private seller');

select * from store_purchase_types;