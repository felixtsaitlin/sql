
drop table book_store.books;

CREATE TABLE `books` (
  `book_id` int unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  `translator` varchar(45),
  `publisher` varchar(45) NOT NULL,
  `year_published` int unsigned NOT NULL,
  `num_pages` int unsigned NOT NULL,
  `weight` int unsigned NOT NULL,
  `conditions` int unsigned NOT NULL,
  `edition` int unsigned NOT NULL,
  `date_added_to_stock` date,
  `copies_sold` int unsigned,
  `location_id` int unsigned,
  
  PRIMARY KEY (`book_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


select * from book_store.books;

insert 
into book_store.books (book_id, title,translator,publisher,year_published,
                       num_pages,weight,conditions,edition,date_added_to_stock,copies_sold,location_id) 
values (1,'object oriented', 'roee leon', 'zoom',2020,200,3,1,1,'2020-01-01',180,1);

insert 
into book_store.books (book_id, title,translator,publisher,year_published,
                       num_pages,weight,conditions,edition,date_added_to_stock,copies_sold,location_id) 
values (2,'Harry Potter','j k rolling','stimatski',1999,400,2,1,1,'2000-01-01',100,1);

insert into book_store.books (book_id, title,translator,publisher,year_published,
                       num_pages,weight,conditions,edition,date_added_to_stock,copies_sold,location_id) 
values (3,'Harry Potter','avi nusbaum','stimatski',2001,450,3,1,1,'2002-01-01',50,2);

insert into book_store.books (book_id, title,translator,publisher,year_published,
                       num_pages,weight,conditions,edition,date_added_to_stock,copies_sold,location_id) 
values (4,'Harry Potter','ayub kara','masada',2003,350,2,1,1,'2004-01-01',40,1);

insert into book_store.books (book_id, title,translator,publisher,year_published,
                       num_pages,weight,conditions,edition,date_added_to_stock,copies_sold,location_id) 
values (5,'Pokemon - the book','yushimoto nigiri','mitsubishi',2005,500,4,1,1,'2005-02-05',200,2);

insert into book_store.books (book_id, title,translator,publisher,year_published,
                       num_pages,weight,conditions,edition,date_added_to_stock,copies_sold,location_id) 
values (6,'Pokemon - the book','erez tal', 'keshet',2007,700,5,1,2,'2008-03-10',150,2);

insert into book_store.books (book_id, title,translator,publisher,year_published,
                       num_pages,weight,conditions,edition,date_added_to_stock,copies_sold,location_id) 
values (7,' introductin to algoritems ','avivit levi' ,'software', 2017,200,3,1,1,'2018-10-30',300,1);

insert into book_store.books (book_id, title,translator,publisher,year_published,
                       num_pages,weight,conditions,edition,date_added_to_stock,copies_sold,location_id) 
values (8,'c programing ','marcelo shichman', 'shenkar', 2018, 300,4,1,1,'2019-03-09',250,1);

insert into book_store.books (book_id, title,translator,publisher,year_published,
                       num_pages,weight,conditions,edition,date_added_to_stock,copies_sold,location_id) 
values (9,'file systems', 'itshak nudler', 'shenkar', 2018,400,5,1,1,'2018-11-01',130,1);

insert into book_store.books (book_id, title,translator,publisher,year_published,
                       num_pages,weight,conditions,edition,date_added_to_stock,copies_sold,location_id) 
values (10,'mano', 'igal hofner', 'shenkar',2016, 150,1,1,2,'2016-05-30',90,1);

insert into book_store.books (book_id, title,translator,publisher,year_published,
                       num_pages,weight,conditions,edition,date_added_to_stock,copies_sold,location_id) 
values (11,'27 ways to make a man say no', 'loli luli', 'shenkar',2014, 206,3,2,2,'2018-11-05',3,1);

SELECT count(*) FROM book_store.books WHERE title = 'Pokemon - the book';
select * from book_store.books;

select book_id,title from books;

select author_id,author_name from authors;

select * from books;

select  count(*),title
from books group by title order by count(*) desc;

select * from books;



