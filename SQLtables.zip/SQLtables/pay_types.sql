drop table pay_methods;

CREATE TABLE `pay_methods` (
`pay_method_id` int NOT NULL AUTO_INCREMENT,
`pay_method_name` varchar(45) NOT NULL,

PRIMARY KEY (`pay_method_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

insert 
into book_store.pay_methods (pay_method_id, pay_method_name) 
values (1,'cerdit card');

insert 
into book_store.pay_methods (pay_method_id, pay_method_name) 
values (2,'bit');

insert 
into book_store.pay_methods (pay_method_id, pay_method_name) 
values (3,'transfer');


select 	sum(tran_val)
from 	transactions
where 	tran_date >= '2018-05-01' and 
		tran_date < '2018-06-01' and
        pay_method_id = 2;
select * from pay_methods;
select * from transactions;