drop table `status_for_shipments`;

