drop table book_store.bookConditions;

CREATE TABLE `bookConditions` (
  `bookConditions_id` int NOT NULL AUTO_INCREMENT,
  `conditions` varchar(45) NOT NULL,
  PRIMARY KEY (`bookConditions_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

select * from book_store.bookConditions;

insert 
into book_store.bookConditions (bookConditions_id, conditions) 
values (1,'new');

insert 
into book_store.bookConditions (bookConditions_id, conditions) 
values (2,'as new');

insert 
into book_store.bookConditions (bookConditions_id, conditions) 
values (3,'good');

insert 
into book_store.bookConditions (bookConditions_id, conditions) 
values (4,'ok');

insert 
into book_store.bookConditions (bookConditions_id, conditions) 
values (5,'bad');