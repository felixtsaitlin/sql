
drop table book_locations;

CREATE TABLE `book_locations` (
  `location_id` int unsigned NOT NULL,
  `location_name` varchar(45) NOT NULL,
  
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

insert 
into book_store.book_locations (location_id, location_name) 
values (1,'store');

insert 
into book_store.book_locations (location_id, location_name) 
values (2,'warehouse');

select* from book_locations;