drop table worker_salary;

CREATE TABLE `worker_salary` (
`worker_id` int NOT NULL AUTO_INCREMENT,
`year_val` int NOT NULL,
`month_val` int NOT NULL,
`salary` int unsigned,
`hours` int unsigned,
`trans_count` int unsigned,
PRIMARY KEY (`worker_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

insert into worker_salary (worker_id, year_val, month_val,salary,hours,trans_count )
values(1, 2019, 3,2000,50,20 ) ;

insert into worker_salary (worker_id, year_val, month_val,salary,hours,trans_count )
values(2, 2019, 3,3400,70,50 ) ;

insert into worker_salary (worker_id, year_val, month_val,salary,hours,trans_count)
values(3, 2018, 4,5000,120,80 ) ;

insert into worker_salary (worker_id, year_val, month_val,salary,hours,trans_count )
values(4, 2017, 2,3700, 100,60) ;

insert into worker_salary (worker_id, year_val, month_val,salary,hours,trans_count )
values(5, 2016, 4,4000,140,70) ;

insert into worker_salary (worker_id, year_val, month_val,salary,hours,trans_count )
values(6, 2019, 3,5500, 150,100) ;

insert into worker_salary (worker_id, year_val, month_val,salary,hours,trans_count )
values(7, 2020, 7, 6200,180,120) ;

insert into worker_salary (worker_id, year_val, month_val,salary,hours,trans_count )
values(8, 2015, 9, 3800,130,65) ;

insert into worker_salary (worker_id, year_val, month_val,salary,hours,trans_count )
values(9, 2010, 10 ,4600,150,120) ;

insert into worker_salary (worker_id, year_val, month_val,salary,hours,trans_count )
values(10, 2005, 11,1500,40,30 ) ;

select * from worker_salary;






      
     /*26*/                    
select 	worker_salary.worker_id,year_val,month_val,trans_count,
from 	worker_salary
where 	year_val=2019 and month_val=3 and 
        trans_count = (	select 	max(trans_count) 
						from 	worker_salary 
						where 	year_val=2019 and 
								month_val=3 ); 
                                
