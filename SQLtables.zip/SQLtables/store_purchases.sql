drop table store_purchases;

CREATE TABLE `store_purchases` (
`store_pur_id` int NOT NULL AUTO_INCREMENT,
`store_pur_date` date,
`store_pur_val` int unsigned,
`book_id` int unsigned,
`purchase_from_id` int unsigned,

PRIMARY KEY (`store_pur_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

insert into store_purchases (store_pur_id, store_pur_date, store_pur_val,book_id,purchase_from_id )
values(1,'2010-01-01',182,1,1 ) ;

insert into store_purchases (store_pur_id, store_pur_date, store_pur_val,book_id,purchase_from_id )
values(2,'2011-09-20',120,1,1 ) ;

insert into store_purchases (store_pur_id, store_pur_date, store_pur_val,book_id,purchase_from_id)
values(3,'2015-04-01',140,3,3 ) ;

insert into store_purchases (store_pur_id, store_pur_date, store_pur_val,book_id,purchase_from_id )
values(4,'2017-01-02',200,4,1 ) ;

insert into store_purchases (store_pur_id, store_pur_date, store_pur_val,book_id,purchase_from_id )
values(5,'2017-01-15',444,2,2 ) ;

insert into store_purchases (store_pur_id, store_pur_date, store_pur_val,book_id,purchase_from_id )
values(6,'2017-02-02',222,7,2 ) ;

insert into store_purchases (store_pur_id, store_pur_date, store_pur_val,book_id,purchase_from_id  )
values(7,'2018-05-01',222,4,1 ) ;

insert into store_purchases (store_pur_id, store_pur_date, store_pur_val,book_id,purchase_from_id  )
values(8,'2018-05-30',458,6 ,1) ;

insert into store_purchases (store_pur_id, store_pur_date, store_pur_val,book_id,purchase_from_id  )
values(9,'2018-05-12',129,2,1 ) ;

insert into store_purchases (store_pur_id, store_pur_date, store_pur_val,book_id,purchase_from_id  )
values(10,'2019-02-08',100,8,1) ;

insert into store_purchases (store_pur_id, store_pur_date, store_pur_val,book_id,purchase_from_id  )
values(11,'2020-05-01',483,2,3 ) ;

insert into store_purchases (store_pur_id, store_pur_date, store_pur_val,book_id,purchase_from_id  )
values(12,'2020-06-01',60,5,3 ) ;

insert into store_purchases (store_pur_id, store_pur_date, store_pur_val,book_id,purchase_from_id  )
values(13,'2020-07-01',80,4,1 ) ;

select * from store_purchases;

select * from store_purchases order by store_pur_date;

select count(*),sum(store_pur_val)
from store_purchases 
where store_pur_date between '2017-01-01' and '2020-01-01';

 select count(*),sum(store_pur_val)
                            from store_purchases
                            where store_pur_date between '2018-01-01' and '2020-01-01';

                      
	select 	sum(store_pur_val)
	from 	store_purchases
	where 	store_pur_date >= '%d-%d-01' and 
			store_pur_date < '%d-%d-01'; 
