drop table worker;

CREATE TABLE `worker` (
`worker_id` int NOT NULL AUTO_INCREMENT,
`first_name` varchar(45) NOT NULL,
`last_name` varchar(45) NOT NULL,
`adress` varchar(45) NOT NULL,
`cell_phone` varchar(45) NOT NULL,
PRIMARY KEY (`worker_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

insert into worker (worker_id, first_name, last_name,adress,cell_phone )
values(1,'avi','moshe','herzel 3','053-3333333') ;

insert into worker (worker_id, first_name, last_name,adress,cell_phone )
values(2,'david','levi', 'zabutinski 5','055-5555555') ;

insert into worker (worker_id, first_name, last_name,adress,cell_phone )
values(3,'shimon','gershon','rotshild 7', '054-4447777') ;

insert into worker (worker_id, first_name, last_name,adress,cell_phone )
values(4,'shalom','byebye', 'lishanski 10','052-33445267') ;

insert into worker (worker_id, first_name, last_name,adress,cell_phone )
values(5,'nisim','cohen','alon 20','054-3454444') ;


insert into worker (worker_id, first_name, last_name,adress,cell_phone )
values(6,'dani','dan','dandan 33 neve dan','058-1122334') ;


insert into worker (worker_id, first_name, last_name,adress,cell_phone )
values(7,'hila','hason','ramat hagolan','054-4444332') ;


insert into worker (worker_id, first_name, last_name,adress,cell_phone )
values(8,'leonid','borovich','herzl 33 netania','052-8927343') ;


insert into worker (worker_id, first_name, last_name,adress,cell_phone )
values(9,'yaakov','levi','maale michmash','054-4322548') ;


insert into worker (worker_id, first_name, last_name,adress,cell_phone )
values(10,'reut','benizry','yerushalayim','056-9027834') ;

select worker.worker_id,year_val,month_val,salary,first_name,last_name
                          from worker_salary,worker
                          where worker.worker_id =1 and year_val = 2019 and month_val = 3;