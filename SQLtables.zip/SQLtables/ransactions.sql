drop table transactions;

CREATE TABLE `transactions` (
`transactions_id` int NOT NULL AUTO_INCREMENT,
`worker_id` int unsigned,
`year_val` int unsigned,
`month_val`int unsigned,
`transaction_val` int unsigned,

PRIMARY KEY (`worker_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

insert into transactions (transactions_id, worker_id, year_val,month_val,transaction_val )
values(1,1,2020,3,200 ) ;

insert into transactions (transactions_id, worker_id, year_val,month_val,transaction_val )
values(2,1,2019, 2,300) ;

insert into transactions (transactions_id, worker_id, year_val,month_val,transaction_val )
values(3,2,2019,2 ,400) ;

insert into transactions (transactions_id, worker_id, year_val,month_val,transaction_val )
values(4,2,2020,3,100) ;

insert into transactions (transactions_id, worker_id, year_val,month_val,transaction_val )
values(5,1,2018,3,400 ) ;

